#ifndef SYSTEM_CORE_GRAPHICS_BASE_H_
#define SYSTEM_CORE_GRAPHICS_BASE_H_

#include "graphics-base-v1.0.h"
#include "graphics-base-v1.1.h"
#include "graphics-base-v1.2.h"

#endif  // SYSTEM_CORE_GRAPHICS_BASE_H_
